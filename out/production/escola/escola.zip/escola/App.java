package escola;

import escola.menu.Menu;
import escola.repositorio.RepositorioAlunos;
import escola.repositorio.RepositorioDisciplinas;

public class App {
    public static void main(String[] args) {
        RepositorioAlunos.inicializar();
        RepositorioDisciplinas.inicializar();
        Menu.run();
    }
}
