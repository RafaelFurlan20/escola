package escola.menu;

import java.util.Scanner;


public class MenuBoletim {
    private static final Scanner sc = new Scanner(System.in);

public static void escolha(int opcao) {
    switch (opcao) {
        case 1:
            MenuPrint.enviarBoletimEmail();
            String email = sc.next();
            break;
        case 2:
            MenuPrint.enviarBoletimTelefone();
            int telefone = sc.nextInt();
            break;
        case 3:
            MenuPrint.imprimirBoletim();
            break;
        case 4:
            Menu.run();
            break;
        default:
            MenuPrint.escolhaInvalida();
            break;
    }
}
}
