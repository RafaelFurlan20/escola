package escola.menu;

public class MenuPrint {
    public static void printarMenu(){
        System.out.println("1- Cadastrar Aluno\n2- Adicionar notas\n3- Enviar Boletim ");
    }
    public static void escolhaCpf(){
        System.out.println("Digite o cpf do Aluno:");
    }
    public static void alunoNaoEncontrado(){
        System.out.println("Aluno não Cadastrado, voltando para o menu principal");
    }
    public static void boletimEscolha(){
        System.out.println("Deseja enviar o seguinte boletim, por qual plataforma:\n1- Email\n2- Telefone\n3- Imprimir" +
                "\n4- Voltar para o menu principal");
    }
    public static void enviarBoletimTelefone(){
        System.out.println("Digite o número de telefone:");
    }
    public static void enviarBoletimEmail(){
        System.out.println("Digite o email");
    }
    public static void imprimirBoletim(){
        System.out.println("Imprimindo...");
    }
    public static void escolhaInvalida(){
        System.out.println("Escolha Inválida!");
    }
}
