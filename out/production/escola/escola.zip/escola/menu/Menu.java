package escola.menu;

import escola.modelo.Aluno;
import escola.modelo.Disciplina;
import escola.cadastro.CadastroAlunos;
import escola.cadastro.CadastroDisciplina;
import escola.mostrar.PrintBoletim;
import escola.repositorio.RepositorioAlunos;
import escola.repositorio.RepositorioDisciplinas;

import java.util.List;
import java.util.Scanner;

public class Menu {
    private static final Scanner sc = new Scanner(System.in);
    public static void run(){

        MenuPrint.printarMenu();
        int opcao = sc.nextInt();
        int cpf;
        Aluno aluno;
        switch (opcao) {
            case 1:
                aluno = CadastroAlunos.cadastrar(sc);
                RepositorioAlunos.salvar(aluno);
                break;
            case 2:
                MenuPrint.escolhaCpf();
                cpf = sc.nextInt();
                aluno = RepositorioAlunos.getAluno(cpf);
                if (aluno == null) {
                    MenuPrint.alunoNaoEncontrado();
                } else {
                    RepositorioDisciplinas.salvar(aluno, CadastroDisciplina.run(sc));
                }

                break;
            case 3:
                MenuPrint.escolhaCpf();
                cpf = sc.nextInt();
                List<Disciplina> lista = RepositorioDisciplinas.getListaDisciplinas(cpf);
                MenuPrint.boletimEscolha();
                opcao = sc.nextInt();
                MenuBoletim.escolha(opcao);
                PrintBoletim.print(lista,RepositorioAlunos.getAluno(cpf).nome);
                break;
            default:
                MenuPrint.escolhaInvalida();
                break;
        }
        Menu.run();
    }
   
}
