package escola.modelo;

public class Disciplina {

    public String nome;
    public float nota;
    public float cargaHoraria;

    public Disciplina(String nome, float nota, float cargaHoraria) {
        this.nome = nome;
        this.nota = nota;
        this.cargaHoraria = cargaHoraria;
    }

}
