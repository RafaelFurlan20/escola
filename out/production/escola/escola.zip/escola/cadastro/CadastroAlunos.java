package escola.cadastro;

import escola.modelo.Aluno;

import java.util.Scanner;

public class CadastroAlunos {
    public static Aluno cadastrar(Scanner sc) {
        System.out.println("Informe as seguintes informações");

        System.out.print("Informe o CPF do Aluno:");
        int cpf = sc.nextInt();

        System.out.print("Informe o nome do Aluno:");
        String nome = sc.next();

        Aluno aluno = new Aluno(nome, cpf);
        return aluno;
    }
}