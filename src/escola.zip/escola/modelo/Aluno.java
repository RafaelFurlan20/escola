package escola.modelo;

public class Aluno extends Pessoa {

    public Aluno(String nome, int cpf) {
        super(nome, cpf);
    }

}
