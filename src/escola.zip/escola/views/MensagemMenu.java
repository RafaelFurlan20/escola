package escola.views;

public class MensagemMenu {
    public static void printarMenu(){
        System.out.println("1- Cadastrar Aluno\n2- Adicionar notas\n3- Enviar Boletim ");
    }
    public static void escolhaInvalida(){
        System.out.println("Escolha Inválida!");
    }
}
