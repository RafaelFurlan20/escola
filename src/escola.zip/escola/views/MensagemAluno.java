package escola.views;

public class MensagemAluno {
    public static void escolhaCpf(){
        System.out.println("Digite o cpf do Aluno:");
    }
    public static void alunoNaoEncontrado(){
        System.out.println("Aluno não Cadastrado, voltando para o menu principal");
    }

}
